package com.cg.bean;

import java.time.LocalDate;
import java.util.ArrayList;

public class customer {
	
	private int AccNo;
	private String name;
	private double balance;
	private long contact;
	
	private LocalDate date;
	
	public ArrayList<String> getList() {
		return list;
	}
	public void setList(ArrayList<String> list) {
		this.list = list;
	}
	
	private ArrayList<String> list =new ArrayList<>();
	
	public int getAccNo() {
		return AccNo;
	}
	public void setAccNo(int accNo) {
		AccNo = accNo;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	public long getContact() {
		return contact;
	}
	public void setContact(long contact) {
		this.contact = contact;
	}
	
	public LocalDate getDate() {
		return date;
	}
	public void setDate(LocalDate date) {
		this.date = date;
	}
	@Override
	public String toString() {
		return "customer [AccNo=" + AccNo + ", name=" + name + ", balance=" + balance + ", contact=" + contact
				+ ", date=" + date + "]";
	}
	


}
