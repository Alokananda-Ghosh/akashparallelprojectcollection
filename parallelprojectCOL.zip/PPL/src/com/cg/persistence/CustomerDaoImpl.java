package com.cg.persistence;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Set;

import com.cg.bean.customer;



public class CustomerDaoImpl implements ICustomerDao
{

	HashMap<Integer,customer> hm=new HashMap<>();
	
	public void putdata(int id, String name, long contact,LocalDate date, double balance) 
	{
		// TODO Auto-generated method stub
		customer ob=new customer();
		ob.setAccNo(id);
		ob.setName(name);
		ob.setContact(contact);
		ob.setDate(date);
		ob.setBalance(balance);
		
		hm.put(ob.getAccNo(),ob);
		
	}

	@Override
	public void showdetails() {
		// TODO Auto-generated method stub
	
		Set<Integer> bc=hm.keySet();
		Iterator<Integer> it=bc.iterator();
		while(it.hasNext())
		{
			int i=it.next();
			customer ob2=hm.get(i);
			System.out.println(ob2);
			
				
		}
	}

	@Override
	public void withdraw(int AccNo, double bal) {
		// TODO Auto-generated method stub
		customer b=hm.get(AccNo);
		double CBal=b.getBalance();
		if(CBal>bal)
		{
			double temp=CBal-bal;
			if(temp>500)
			{
				ArrayList<String> l=b.getList();
				String st=b.getName()+" withdraw "+bal+" from account "+" on "+ LocalDate.now()+" at "+LocalTime.now();
				l.add(st);
				b.setList(l);
				
				b.setBalance(temp);
			}
			else
			{
				System.out.println("sorry you do not have enough balance");
			}
				
		}
		else
			System.out.println("sorry you do not have enough balance");
	}

	@Override
	public void deposit(int AccNo, double bal) {
		
		// TODO Auto-generated method stub
		
		customer b=hm.get(AccNo);
		double CBal=b.getBalance();
		double temp=CBal+bal;
		if(temp>=1000000)
		{
			System.out.println("sorry we could not proceed you reached max limit");
		}
		else
		{
			ArrayList<String> l=b.getList();
			String st=b.getName()+" deposited "+bal+" on "+ LocalDate.now()+" at "+LocalTime.now();
			l.add(st);
			b.setList(l);
			
			b.setBalance(temp);
		}
		
		
	}
	public void transaction(int id1,int id2,double amt)
	{
		customer b=hm.get(id1);
		customer b2=hm.get(id2);
		double CBal=b.getBalance();
		if(CBal>amt)
		{
			double temp=CBal-amt;
			if(temp>500)
			{
				double CBal2=b2.getBalance()+amt;
				if(CBal2>=1000000)
				{
					System.out.println("sorry we could not proceed you reached max limit");
				}
				else
				{
					b2.setBalance(CBal2);
					b.setBalance(temp);
					
					ArrayList<String> l=b.getList();
					String st=b.getName()+" Transfered "+amt+" to "+b2.getName()+" on "+ LocalDate.now()+" at "+LocalTime.now()+"   "+"Current Balance = "+ b.getBalance();
					l.add(st);
					b.setList(l);
					
					ArrayList<String> l2=b2.getList();
					String st2=b.getName()+" Transfered "+amt+" to "+b2.getName()+" on "+ LocalDate.now()+" at "+LocalTime.now()+"   "+"Current Balance = "+ b2.getBalance();
					l2.add(st2);
					b2.setList(l2);
					
					System.out.println(b.getName()+" Transfered "+amt+" to "+b2.getName()+" on "+ LocalDate.now()+" at "+LocalTime.now()+"   "+"Current Balance = "+ b.getBalance());
				}
			}
			else
			{
				System.out.println("sorry you do not have enough balance");
			}
				
		}
		else
			System.out.println("sorry you do not have enough balance");
		
	}
	public void search(String name2)
	{
		
		Set<Integer> bc=hm.keySet();
		Iterator<Integer> it=bc.iterator();
		while(it.hasNext())
		{
			int i=it.next();
			customer ob2=hm.get(i);
			if(ob2.getName().equals(name2))
				System.out.println(ob2);
			else
				System.out.println("record not found");
			
				
		}
	}
	public void printTransaction(int AccNo)
	{
		ArrayList<String> l=hm.get(AccNo).getList();
		Iterator<String> itr=l.iterator();
		System.out.println("All Transactions are:--------");
		while(itr.hasNext())
		{
			System.out.println(itr.next());
		}
		
	}

}
