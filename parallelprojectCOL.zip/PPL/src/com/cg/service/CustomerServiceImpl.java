package com.cg.service;

import java.time.LocalDate;

import com.cg.persistence.CustomerDaoImpl;

public class CustomerServiceImpl implements ICustomerService{

	CustomerDaoImpl ob=new CustomerDaoImpl();


	@Override
	public void showdetails() {
		// TODO Auto-generated method stub
		ob.showdetails();
	}

	@Override
	public void withdraw(int AccNo, double bal) {
		// TODO Auto-generated method stub
		ob.withdraw(AccNo,bal);
	}
	public void deposit(int AccNo, double bal) {
		// TODO Auto-generated method stub
		ob.deposit(AccNo,bal);
	}
	public void transaction(int id1,int id2,double amt)
	{
		ob.transaction(id1, id2, amt);
	}

	@Override
	public void search(String name2) {
		// TODO Auto-generated method stub
		ob.search(name2);
	}

	@Override
	public void printTransaction(int AccNo) {
		// TODO Auto-generated method stub
		ob.printTransaction(AccNo);
		
	}

	@Override
	public void putdata(int id, String name, long contact,LocalDate date, double balance) {
		// TODO Auto-generated method stub
		ob.putdata(id, name, contact,date, balance);
	}
	

}
