package com.cg.service;

import java.time.LocalDate;

public interface ICustomerService {
	public void putdata(int id,String name,long contact,LocalDate date,double balance);
	public void showdetails();
	public void withdraw(int AccNo,double bal);
	public void deposit(int AccNo,double bal);
	public void transaction(int id1,int id2,double amt);
	public void search(String name2);
	public void printTransaction(int AccNo);
}
