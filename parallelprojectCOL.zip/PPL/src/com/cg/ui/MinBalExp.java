package com.cg.ui;

public class MinBalExp extends Exception {
	
	MinBalExp(String msg)
	{
		super(msg);
	}

}
