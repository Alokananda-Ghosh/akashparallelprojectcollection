package com.cg.ui;

import java.time.LocalDate;
import java.util.Random;
import java.util.Scanner;

import com.cg.service.CustomerServiceImpl;

public class XYZBank
{
 public static void main(String[] args) 
 	{
	 	Scanner sc=new Scanner(System.in);
	 	CustomerServiceImpl ob=new CustomerServiceImpl();
	 	Random rd=new Random();
	 	
	 	char s;
	 	do
	 	{
	 		System.out.println("press 1 to create acc\n 2 to show details \n 3 to withdraw \n 4 to deposit \n 5 to transfer money \n 6 to search any account \n 7 to print all transaction \n 8 to exit");
	 		int n=sc.nextInt();
	 		switch(n)
	 		{
	 		case 1:
	 				System.out.println("enter Name, Contact no, the Opening Amount to open account and dateOfBirth(yyyy-mm-dd)");
	 				String name=sc.next();
	 				long contact=sc.nextLong();
	 				double balance=sc.nextDouble();
	 				
	 				try{
	 					if(balance<=500)
	 			
	 					{
	 						throw new MinBalExp("min 500 bal is required");
	 					}
	 				
	 				}
	 				catch(MinBalExp e)
	 				{
	 					System.out.println(e);
	 					System.out.println("enter balance again but >500");
	 					balance=sc.nextDouble();

	 				}
	 				int[] a=new int[3];
	 				int[] b=new int[3];
	 				String str3=sc.next();
	 				String s1[]=str3.split("-");
	 				for(int i=0;i<=2;i++)
	 				{
	 					
	 					a[i]=Integer.parseInt(s1[i]);
	 				}
	 				LocalDate d=LocalDate.of(a[0], a[1], a[2]);
	 				int AccNo=rd.nextInt(100000);
	 				ob.putdata(AccNo, name, contact,d, balance);
	 				break;
	 		case 2:
	 				ob.showdetails();
	 				break;
	 		case 3:
	 				ob.showdetails();
	 				System.out.println("enter your AccNo");
	 				int AccNo2=sc.nextInt();
	 				System.out.println("enter balance to withdraw");
	 				double bal=sc.nextDouble();
	 				ob.withdraw(AccNo2,bal);
	 				break;
	 		case 4:
	 				ob.showdetails();
	 				System.out.println("enter your AccNo");
	 				int AccNo3=sc.nextInt();
	 				System.out.println("enter balance to deposit");
	 				double bal3=sc.nextDouble();
 					ob.deposit(AccNo3,bal3);
 					break;
	 		case 5:
	 				ob.showdetails();
	 				System.out.println("enter your accNo and the accNo you want to transfer");
	 				int id1=sc.nextInt();
	 				int id2=sc.nextInt();
	 				System.out.println("enter amount to transfer");
	 				double amt=sc.nextDouble();
	 				ob.transaction(id1,id2,amt);
	 				break;
	 		case 6:
	 				System.out.println("enter name to search");
	 				String name2=sc.next();
	 				ob.search(name2);
	 				break;
	 				
	 		case 7:
	 				ob.showdetails();
	 				System.out.println("enter the accNo you want to see all transaction details");
	 				int AccNo4=sc.nextInt();
	 				ob.printTransaction(AccNo4);
	 				break;
	 			
	 		case 8:
	 				System.exit(1);
	 				break;
	 		default:
	 				System.out.println("wrong input");
	 				
	 		}
	 	
	 	}while(true);
 	}
}
